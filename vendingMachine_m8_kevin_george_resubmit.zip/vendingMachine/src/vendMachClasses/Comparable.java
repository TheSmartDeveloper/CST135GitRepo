package vendMachClasses;

public interface Comparable
{
	void comparedTo(Product p1, Product p2);
}